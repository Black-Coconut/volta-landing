// App shell: nav + tweaks panel + section composition.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "dark",
  "lang": "ko",
  "accentHue": 130,
  "headlineSerif": true,
  "showGrid": true
}/*EDITMODE-END*/;

function Nav({ t, lang, setLang }) {
  return (
    <nav style={{
      position: "sticky", top: 0, zIndex: 50,
      backdropFilter: "blur(14px)",
      WebkitBackdropFilter: "blur(14px)",
      background: "color-mix(in oklch, var(--bg), transparent 30%)",
      borderBottom: "1px solid var(--line-soft)",
    }}>
      <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}>
        <a href="#" style={{ display: "flex", alignItems: "center", gap: 10, color: "var(--fg)" }}>
          <VoltaMark size={24} />
          <VoltaWordmark height={20} />
        </a>
        <div style={{ display: "flex", alignItems: "center", gap: 28, fontSize: 13, color: "var(--fg-2)" }}>
          <a href="#how">{t.nav.how}</a>
          <a href="#pricing">{t.nav.pricing}</a>
          <a href="#faq">{t.nav.faq}</a>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            display: "inline-flex", border: "1px solid var(--line)",
            borderRadius: 999, overflow: "hidden", fontFamily: "var(--mono)", fontSize: 11,
          }}>
            {["ko", "en"].map((l) => (
              <button
                key={l}
                onClick={() => setLang(l)}
                style={{
                  padding: "5px 12px", border: "none", cursor: "pointer",
                  background: lang === l ? "var(--fg)" : "transparent",
                  color: lang === l ? "var(--bg)" : "var(--fg-2)",
                  textTransform: "uppercase", letterSpacing: "0.06em",
                }}
              >{l}</button>
            ))}
          </div>
          <a href="#" className="btn btn-ghost" style={{ height: 36, padding: "0 12px" }}>{t.nav.login}</a>
          <a href="#waitlist" className="btn btn-primary" style={{ height: 36 }}>{t.nav.waitlist}<span className="arrow">→</span></a>
        </div>
      </div>
    </nav>
  );
}

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const lang = tweaks.lang;
  const setLang = (l) => setTweak("lang", l);
  const t = useT(lang);

  // Apply theme + accent hue to root
  React.useEffect(() => {
    const r = document.documentElement;
    r.setAttribute("data-theme", tweaks.theme);
    r.style.setProperty("--accent",     `oklch(0.88 0.22 ${tweaks.accentHue})`);
    r.style.setProperty("--accent-2",   `oklch(0.78 0.22 ${tweaks.accentHue})`);
    r.style.setProperty("--accent-dim", `oklch(0.55 0.18 ${tweaks.accentHue})`);
    document.documentElement.lang = lang;
  }, [tweaks.theme, tweaks.accentHue, lang]);

  return (
    <React.Fragment>
      <Nav t={t} lang={lang} setLang={setLang} />
      <Hero t={t} lang={lang} />
      <DAWStrip t={t} />
      <IntentSection t={t} />
      <MultitrackSection t={t} />
      <CompareSection t={t} />
      <HowSection t={t} />
      <CasesSection t={t} />
      <PricingSection t={t} />
      <FAQSection t={t} />
      <WaitlistSection t={t} />
      <Footer t={t} />

      <TweaksPanel title="Tweaks">
        <TweakSection title="Appearance">
          <TweakRadio
            label="Theme"
            value={tweaks.theme}
            onChange={(v) => setTweak("theme", v)}
            options={[{ value: "dark", label: "Dark" }, { value: "light", label: "Light" }]}
          />
          <TweakSlider
            label="Accent hue"
            value={tweaks.accentHue}
            min={0} max={360} step={1}
            onChange={(v) => setTweak("accentHue", v)}
            suffix="°"
          />
        </TweakSection>
        <TweakSection title="Language">
          <TweakRadio
            label="Locale"
            value={tweaks.lang}
            onChange={(v) => setTweak("lang", v)}
            options={[{ value: "ko", label: "한국어" }, { value: "en", label: "English" }]}
          />
        </TweakSection>
      </TweaksPanel>
    </React.Fragment>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);

# Handoff: Volta Landing Page

## Overview
Marketing landing page for **Volta**, a conversational mixing agent that runs as an extension inside Ableton Live, Cubase, and Logic Pro. The page exists to drive the Q3 2026 beta waitlist signup; secondary goal is to communicate two flagship capabilities — *intent-aware mixing* (natural-language → DSP decisions) and *multitrack parameter control* (coordinated edits across many tracks/devices in one move).

The product name comes from the **volta** musical sign — a bracket over a numbered ending that tells a player which repeat to take. The brand uses that bracket motif.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy directly. The HTML uses inline JSX transpiled in the browser via Babel standalone, which is fine for a design prototype but not for production.

The task is to **recreate this design in the target codebase's existing environment** — likely Next.js / Astro / Remix with a real CSS strategy (CSS modules, Tailwind, vanilla-extract) — using its established patterns. If no environment exists yet, **Next.js (App Router) + Tailwind** is a reasonable default for a marketing site.

## Fidelity
**High-fidelity.** Final colors, typography scale, spacing, copy, and interactions are all settled. Recreate pixel-perfectly using the codebase's existing libraries.

The page is currently **desktop-only** (≥ 1024px). The developer should add responsive breakpoints during implementation; layout intent is described per-section below.

## Tech Stack Suggestions
- **Framework**: Next.js (App Router) for SSR + good i18n primitives
- **Styling**: Tailwind, CSS modules, or vanilla-extract — anything that supports `oklch()` and CSS custom properties
- **i18n**: `next-intl` or similar — the Korean copy is primary, English is the secondary translation. The current prototype has both locales fully written and switchable.
- **Fonts**: All Google Fonts — see "Design Tokens → Typography"
- **Dark mode**: Default is dark; light theme is supported via `data-theme="light"` attribute on `<html>`. Tokens reshade automatically. Keep this contract.

---

## Design Tokens

### Colors (dark theme — default)
All colors use OKLCH for perceptual consistency.

| Token              | OKLCH                          | Hex (approx) | Use |
|--------------------|--------------------------------|--------------|-----|
| `--bg`             | `oklch(0.158 0.012 200)`       | `#1a1f21`    | Page background |
| `--bg-2`           | `oklch(0.195 0.013 200)`       | `#22282b`    | Inset / inner surfaces |
| `--surface`        | `oklch(0.225 0.014 200)`       | `#282f31`    | Cards |
| `--surface-2`      | `oklch(0.265 0.014 200)`       | `#30383a`    | Card chrome (header bars) |
| `--line`           | `oklch(0.32 0.012 200)`        | `#3b4244`    | Strong borders |
| `--line-soft`      | `oklch(0.26 0.012 200)`        | `#2f3638`    | Hairline dividers |
| `--fg`             | `oklch(0.97 0.005 200)`        | `#f4f6f6`    | Primary text |
| `--fg-2`           | `oklch(0.78 0.008 200)`        | `#bcc1c2`    | Secondary text / body |
| `--fg-3`           | `oklch(0.58 0.01 200)`         | `#838a8c`    | Tertiary / labels |
| `--fg-4`           | `oklch(0.42 0.01 200)`         | `#5d6365`    | Faint text |
| `--accent`         | `oklch(0.88 0.22 130)`         | `#b6f04a`    | Electric lime — primary accent |
| `--accent-2`       | `oklch(0.78 0.22 130)`         | `#9bd238`    | Accent hover |
| `--accent-dim`     | `oklch(0.55 0.18 130)`         | `#6c8e2b`    | Dim accent (meters) |

Light theme overrides are in `index.html` under `[data-theme="light"]`.

### Typography
All from Google Fonts. Preconnect + import:
```
https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Geist:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap
```
- **Display / serif** — `Instrument Serif`, regular & italic. Used for h1 hero, h2 section headlines, large price numerals, wordmark. Letter-spacing `-0.015em` to `-0.025em`. Always `text-wrap: balance`.
- **Body / sans** — `Geist`, weights 300/400/500/600/700. Default 15px / 1.55 / `-0.005em`. Feature settings `"ss01", "cv11"`.
- **Mono** — `JetBrains Mono`, 400/500. Used for: eyebrows, technical labels, prompt input, diff values, footer meta. Tracking `0.04em–0.12em`, often UPPERCASE 10–13px.

### Spacing & radii
- Base radius `--radius: 6px`, large `--radius-lg: 10px`. Studio-hardware feel — no big rounding.
- Section vertical padding: **120px top/bottom** for major sections, 88px for hero, 140px for waitlist.
- Container: `max-width: 1200px; padding: 0 32px`.

### Motifs
- **Level meter** — animated vertical bars (CSS `@keyframes meter`). 14px tall by default. Accent-colored.
- **Waveform** — deterministic SVG path generator (`waveformPath()` in `src/hero.jsx`). Two mirrored fills (top brighter, bottom dimmer).
- **Grid background** — 32px square grid with radial mask. Used in hero and waitlist sections.
- **Marquee** — DAW logo strip, 32s linear scroll, with edge fade mask.
- **Blink cursor** — `▍` after typing animation.

### Brand mark
The `<VoltaMark>` SVG is in `src/logo.jsx`. It's a square bracket pair enclosing a "1." numeral — a literal stylization of the volta repeat sign. The `<VoltaWordmark>` flanks the word with two `⌐` glyphs as bracket lozenges.

---

## Page Structure

The page is one long scroll. All sections are full-width with the `.container` (1200px) inside. Every section ends with a 1px `--line-soft` bottom border.

### 1. Sticky nav — `Nav` in `src/app.jsx`
- 64px tall, sticky, `backdrop-filter: blur(14px)`, semi-transparent bg.
- Left: `<VoltaMark>` + `<VoltaWordmark>`.
- Center: links — `How it works`, `Pricing`, `FAQ`.
- Right: ko/en pill toggle, "Sign in" ghost button, "Join beta" primary button.

### 2. Hero — `Hero` in `src/hero.jsx`
Two-column grid, `1fr 1.05fr`, gap 64px.

**Left column:**
- Pill: `BETA · Q3 2026` with pulsing accent dot.
- H1: `Instrument Serif`, `clamp(48px, 6.4vw, 88px)`, two lines. Second line is italic + accent-colored (e.g., "여기서 끝납니다" / "labor.").
- 17px body paragraph, `--fg-2`, max-width 520px.
- Two CTAs: primary "Join the beta" (filled accent) + ghost "Watch demo" with play triangle.
- Mono footnote: `Apple Silicon · Windows 11 · 64-bit VST3 / AU / AAX`.

**Right column — live demo card:**
A simulated DAW plugin pane.
- **Chrome bar**: 3 traffic-light dots (red / amber / lime), session label "volta · session 'Track 03 — Mix v14.als'", BPM "120.0", live level meter.
- **Waveform strip**: mono label "VOX LEAD · 02:14 → 02:38 (CHORUS)" + "−6.2 LUFS" right-aligned. SVG waveform, 86px tall.
- **Prompt area**: `"엔지니어"` label, then `›` + typing prompt with blinking caret. Loops through 3 example prompts (~12s cycle).
- **Proposal area**: 4 rows of `[track name | device | delta]`, mono, fade in with 80ms stagger after typing finishes.
- **Footer status**: `↵ APPLY · A/B PREVIEW · ⌘Z UNDO` + `● READY` in accent.

The animation state machine (in `Hero`):
1. **typing** — append chars at 28–58ms each
2. **reveal** — 350ms pause then show proposal
3. **hold** — 4.2s
4. **next** — fade out, advance prompt index, restart

### 3. DAW strip — `DAWStrip` in `src/sections.jsx`
32px vertical padding. Mono label "지원 DAW · Q3 베타" / "Supported DAWs · Q3 beta", then a marquee of 6 DAWs (Ableton Live, Cubase, Logic Pro = live; Pro Tools, Studio One, FL Studio = `SOON` pill). Each entry is `[unicode glyph][name][soon?]`. **The unicode glyphs are placeholders** — replace with proper SVG logos at implementation, with permission/licensing as appropriate.

### 4. Capability 01 — `IntentSection`
"It understands 'warmer.'" — natural-language intent.
- Two-column 1fr / 1.05fr, 80px gap, `align: center`.
- Left: eyebrow + h2 with accent underline (`.uacc` class) + body + 3 bulleted features (each: 18px accent line + label).
- Right: chat-style card. Engineer message (left-border `--fg-3`, mono body), then Volta reply (left-border `--accent`, mono body, dot indicator), then 2 mini diff cards showing `oldValue → newValue` with the new value in accent.

### 5. Capability 02 — `MultitrackSection`
"Tracks & device params, all at once."
- Two-column 1fr / 1.6fr, 80px gap, sticky left column at top: 80px.
- Right column is a simulated **DAW track list with diff overlay**:
  - 8 rows, each row: `[track number 02-mono] [color stripe + name] [device change chips] [meter]`
  - Alternating row backgrounds with 50% opacity tint
  - Each chip is `[device label in --fg-3] [delta in accent]`
  - Header bar: "SESSION · 8 / 32 TRACKS · DIFF VIEW" + "● 11 CHANGES"
  - Footer bar: "HOLD ⌥ TO COMPARE A·B" + "↵ APPLY ALL · ⇧↵ APPLY SELECTED"

### 6. Compare slider — `CompareSection`
Header grid: `minmax(0, 1.4fr) minmax(0, 1fr)` so the Korean serif h2 doesn't break.

**Drag-to-compare slider**:
- 240px tall, full-width, rounded card.
- Background layer = BEFORE waveform (gray, dim). **Label "BEFORE · 기존 워크플로" sits at top-RIGHT** (visible behind the AFTER overlay).
- Foreground layer = AFTER waveform (accent), `clip-path: inset(0 ${100-pos}% 0 0)`. **Label "Volta와 함께 · AFTER" at top-LEFT** (inside clipped region).
- Center handle: 1px accent vertical line + 36px round button with `↔` glyph and lime glow.
- Bottom-center mono hint: "드래그해서 비교".
- Mouse + touch drag, clamped 2–98%.

**Below**: two side-by-side step cards.
- Left card "기존 워크플로 · ~ 1H" with 5 numbered steps in `--fg-3`.
- Right card "Volta와 함께 · ~ 90 SEC" with 3 steps in `--fg`, accent numbering, accent border.

### 7. How it works — `HowSection`
"Inside your DAW, in four steps." 4-column equal grid, with crisp 1px lines on all edges (top + left + each cell's right + bottom). Each cell:
- Top row: step number "01"–"04" in accent + 28px hairline.
- 28px gap, then h3 + body.
- Min-height 220px.

### 8. Cases — `CasesSection`
"Pros, first." 3-column equal grid, 20px gap. Each card has:
- "01 / 03" mono index
- h3 title (믹싱 엔지니어 etc.)
- 14px description
- Bottom-aligned 14-bar level meter, accent.

### 9. Pricing — `PricingSection`
Header grid: `minmax(0, 1.4fr) minmax(0, 1fr)` (same fix as Compare).

3-column tier grid, 20px gap. Tier card:
- "RECOMMENDED" pill on the **Beta** tier (top-left, −10px offset, accent fill, inverse text).
- Mono tier name → 44px serif price (accent if recommended) → 13px description.
- Hairline → bullet list with `+` accent prefix.
- 28px top margin → full-width CTA button (primary if recommended, ghost otherwise).

Tier accent: Beta has `oklch(0.30 0.05 130 / 0.06)` background tint and accent border.

### 10. FAQ — `FAQSection`
Two-column 1fr / 2fr. Left column sticky with eyebrow + h2. Right column is an accordion list — top + bottom 1px borders on each row, click toggles `+` ↔ `−` (accent), body fades in via max-height transition (300ms). One row open at a time; clicking the open row closes it.

### 11. Waitlist CTA — `WaitlistSection` (id `waitlist`)
- Centered, 720px max width, with grid background + radial mask.
- Big serif h2 "다음 세션을 다르게." / "Make your next session different.", 17px subtitle.
- Email form: 320px-min email input (mono, 48px tall) + primary submit button. On submit, button label flips to "초대 메일을 보냈습니다."
- Below: seats progress bar — `847 / 1,200 자리 남음` mono, then 4px-tall track with accent fill at `taken/total %`.

### 12. Footer
- 5-column grid `1.4fr repeat(4, 1fr)`.
- First column: wordmark + tagline + 16-bar accent meter.
- 4 link columns: Product / Company / Resources / Legal.
- Hairline → bottom row: `© 2026 Volta Audio Inc. Seoul · Berlin.` left, `VOLTA-1.0.0-BETA · BUILD 26.04.27` right.

---

## Interactions & Behavior

| Element | Behavior |
|---|---|
| Hero typing demo | Loops automatically through 3 prompt/proposal pairs. Each cycle ≈ 7–10s. State machine: typing → reveal → hold → next. |
| DAW marquee | 32s linear scroll, paused on hover (optional polish). |
| Compare slider | Click anywhere or drag the handle; mouse + touch. Clamped 2–98%. No keyboard support yet — add arrow-key nudging in implementation. |
| FAQ accordion | Click row to expand, click again to collapse. Only one open at a time. 300ms ease max-height transition. |
| Waitlist form | On submit with `@` in value: button label swaps to confirmation. No real backend in prototype. |
| Lang toggle (ko/en) | Updates the `lang` tweak; entire content tree re-renders from `I18N` map. |
| Theme toggle (Tweaks panel) | Sets `data-theme` on `<html>`; CSS variables reshade. |
| Accent hue tweak | Sets `--accent`, `--accent-2`, `--accent-dim` directly on `<html>`. **Drop in production** — keep as a single brand color. |

All hover states: 150ms ease, primary CTA shifts to `--accent-2`, ghost CTA borders shift to `--fg-3`. Arrow icons in CTAs translate `+3px` on hover.

## State Management
- `Hero` keeps three local states: `idx` (current prompt index), `typed` (current chars), `phase`.
- `CompareSection` keeps `pos` (0–100). Drag is tracked with a ref + global mouse/touch listeners.
- `FAQSection` keeps single `open` index.
- `WaitlistSection` keeps `email` + `sent`.
- `App` reads from the **Tweaks store** (theme / lang / accentHue) — see "i18n & Tweaks" below.

In a real app, replace the Tweaks store with framework-native state (Next.js cookies / search params for theme, `next-intl` for lang).

## i18n
- Single source of truth: `I18N` object in `src/i18n.jsx` with `ko` and `en` trees.
- Component pattern: every section receives a `t` prop; never hardcode strings.
- For production, port the `I18N` tree to message catalogs (`messages/ko.json`, `messages/en.json`) and wire through `next-intl`'s `useTranslations()` or equivalent.
- Korean copy is primary; English is the secondary translation. **Keep that order** when adding locales.

## Assets
**No raster assets currently** — everything is CSS, SVG, or text.
- Volta wordmark + monogram: hand-drawn SVG in `src/logo.jsx`.
- DAW logos: **placeholder unicode glyphs** — replace with proper SVG logos (after licensing review) at implementation.
- Waveforms: deterministic procedurally generated SVG paths.

Recommended additions for production: a real OG image (1200×630), favicon set, and proper Apple-touch icons.

## Files in this bundle
- `index.html` — page shell, fonts, CSS tokens, layout primitives
- `src/i18n.jsx` — full ko/en content tree
- `src/logo.jsx` — `<VoltaMark>` + `<VoltaWordmark>`
- `src/hero.jsx` — Hero with typing demo + waveform util
- `src/sections.jsx` — all other sections
- `src/app.jsx` — App shell, Nav, Tweaks panel wiring
- `tweaks-panel.jsx` — Tweaks UI helpers (drop in production; the panel is for design exploration only)

## Out of scope / things to discuss
- **Mobile / tablet** — design is desktop-only. Decide breakpoints with design before implementing.
- **Real DAW logos** — confirm licensing.
- **Tweaks panel** — remove from production build entirely. It's a design-time tool only.
- **Accent hue tweak** — remove. Brand uses one accent.
- **Real backend** for waitlist email collection.
